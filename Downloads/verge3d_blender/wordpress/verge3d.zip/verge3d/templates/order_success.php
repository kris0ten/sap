<div class="v3d-order-form">
  Thank you for your order! We're processing it now and will contact with you soon.
</div>
